using SchedulePlanner.Models;

namespace SchedulePlanner
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonInstructors_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UserControlInstructors uc1 = new();
            panel1.Controls.Add(uc1);
            uc1.Dock = DockStyle.Fill;
        }

        private void buttonLessonsByInsturctor_Click(object sender, EventArgs e)
        {

        }
    }
}
