﻿using SchedulePlanner.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchedulePlanner
{
    public partial class FormEditInstructor : Form
    {
        StudiesContext context = new();

        public Instructor CurrentInstructor { get; set; }

        public FormEditInstructor()
        {
            InitializeComponent();
        }

        private void FormEditInstructor_Load(object sender, EventArgs e)
        {


            if (CurrentInstructor != null)
            {


                employementBindingSource.DataSource = context.Employements.ToList();

                statusBindingSource.DataSource = context.Statuses.ToList();

                bindingSource1.DataSource = CurrentInstructor;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            context.SaveChanges();
            this.Close();
        }
    }
}
