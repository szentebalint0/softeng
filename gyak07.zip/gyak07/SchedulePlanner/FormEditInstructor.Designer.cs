﻿namespace SchedulePlanner
{
    partial class FormEditInstructor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            comboBox2 = new ComboBox();
            bindingSource1 = new BindingSource(components);
            statusBindingSource = new BindingSource(components);
            comboBox1 = new ComboBox();
            employementBindingSource = new BindingSource(components);
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            button2 = new Button();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)statusBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)employementBindingSource).BeginInit();
            SuspendLayout();
            // 
            // comboBox2
            // 
            comboBox2.DataBindings.Add(new Binding("SelectedValue", bindingSource1, "StatusFk", true));
            comboBox2.DataSource = statusBindingSource;
            comboBox2.DisplayMember = "Name";
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(19, 118);
            comboBox2.Margin = new Padding(2);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(373, 23);
            comboBox2.TabIndex = 11;
            comboBox2.ValueMember = "StatusId";
            // 
            // bindingSource1
            // 
            bindingSource1.DataSource = typeof(Models.Instructor);
            // 
            // statusBindingSource
            // 
            statusBindingSource.DataSource = typeof(Models.Status);
            // 
            // comboBox1
            // 
            comboBox1.DataBindings.Add(new Binding("SelectedValue", bindingSource1, "EmployementFk", true));
            comboBox1.DataSource = employementBindingSource;
            comboBox1.DisplayMember = "Name";
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(19, 75);
            comboBox1.Margin = new Padding(2);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(373, 23);
            comboBox1.TabIndex = 10;
            comboBox1.ValueMember = "EmployementId";
            // 
            // employementBindingSource
            // 
            employementBindingSource.DataSource = typeof(Models.Employement);
            // 
            // textBox2
            // 
            textBox2.DataBindings.Add(new Binding("Text", bindingSource1, "Name", true));
            textBox2.Location = new Point(79, 34);
            textBox2.Margin = new Padding(2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(313, 23);
            textBox2.TabIndex = 9;
            // 
            // textBox1
            // 
            textBox1.DataBindings.Add(new Binding("Text", bindingSource1, "Salutation", true));
            textBox1.Location = new Point(19, 34);
            textBox1.Margin = new Padding(2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(58, 23);
            textBox1.TabIndex = 8;
            // 
            // button2
            // 
            button2.Location = new Point(313, 162);
            button2.Margin = new Padding(2);
            button2.Name = "button2";
            button2.Size = new Size(76, 20);
            button2.TabIndex = 7;
            button2.Text = "&Mégse";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.DialogResult = DialogResult.OK;
            button1.Location = new Point(233, 162);
            button1.Margin = new Padding(2);
            button1.Name = "button1";
            button1.Size = new Size(76, 20);
            button1.TabIndex = 6;
            button1.Text = "&Ok";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 18);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(46, 15);
            label1.TabIndex = 12;
            label1.Text = "Titulus:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(79, 18);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 13;
            label2.Text = "Teljes név:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 58);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(107, 15);
            label3.TabIndex = 14;
            label3.Text = "Alkalmazási forma:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 102);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(47, 15);
            label4.TabIndex = 15;
            label4.Text = "Státusz:";
            // 
            // FormEditInstructor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(405, 195);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Margin = new Padding(2);
            Name = "FormEditInstructor";
            Text = "FormEditInstructor";
            Load += FormEditInstructor_Load;
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)statusBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)employementBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button button2;
        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private BindingSource bindingSource1;
        private BindingSource statusBindingSource;
        private BindingSource employementBindingSource;
    }
}