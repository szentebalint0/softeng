﻿namespace SchedulePlanner
{
    partial class FormAddLesson
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            listBoxCourse = new ListBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            listBoxRoom = new ListBox();
            label2 = new Label();
            listBoxDay = new ListBox();
            label3 = new Label();
            listBoxTime = new ListBox();
            label4 = new Label();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 18F);
            label5.Location = new Point(12, 9);
            label5.Name = "label5";
            label5.Size = new Size(319, 57);
            label5.TabIndex = 10;
            label5.Text = "Új óra rögzítése";
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button1.Location = new Point(875, 660);
            button1.Name = "button1";
            button1.Size = new Size(130, 40);
            button1.TabIndex = 11;
            button1.Text = "&Ok";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button2.Location = new Point(1012, 660);
            button2.Name = "button2";
            button2.Size = new Size(130, 40);
            button2.TabIndex = 12;
            button2.Text = "&Mégse";
            button2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 84);
            label1.Name = "label1";
            label1.Size = new Size(80, 30);
            label1.TabIndex = 13;
            label1.Text = "Kurzus:";
            // 
            // listBoxCourse
            // 
            listBoxCourse.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            listBoxCourse.FormattingEnabled = true;
            listBoxCourse.ItemHeight = 30;
            listBoxCourse.Location = new Point(12, 158);
            listBoxCourse.Name = "listBoxCourse";
            listBoxCourse.Size = new Size(279, 454);
            listBoxCourse.TabIndex = 14;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 117);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Szűrés";
            textBox1.Size = new Size(279, 35);
            textBox1.TabIndex = 15;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(297, 117);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Szűrés";
            textBox2.Size = new Size(279, 35);
            textBox2.TabIndex = 18;
            // 
            // listBoxRoom
            // 
            listBoxRoom.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            listBoxRoom.FormattingEnabled = true;
            listBoxRoom.ItemHeight = 30;
            listBoxRoom.Location = new Point(297, 158);
            listBoxRoom.Name = "listBoxRoom";
            listBoxRoom.Size = new Size(279, 454);
            listBoxRoom.TabIndex = 17;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(297, 84);
            label2.Name = "label2";
            label2.Size = new Size(74, 30);
            label2.TabIndex = 16;
            label2.Text = "Terem:";
            // 
            // listBoxDay
            // 
            listBoxDay.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            listBoxDay.FormattingEnabled = true;
            listBoxDay.ItemHeight = 30;
            listBoxDay.Location = new Point(582, 158);
            listBoxDay.Name = "listBoxDay";
            listBoxDay.Size = new Size(279, 454);
            listBoxDay.TabIndex = 20;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(582, 84);
            label3.Name = "label3";
            label3.Size = new Size(57, 30);
            label3.TabIndex = 19;
            label3.Text = "Nap:";
            // 
            // listBoxTime
            // 
            listBoxTime.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            listBoxTime.FormattingEnabled = true;
            listBoxTime.ItemHeight = 30;
            listBoxTime.Location = new Point(867, 158);
            listBoxTime.Name = "listBoxTime";
            listBoxTime.Size = new Size(279, 454);
            listBoxTime.TabIndex = 23;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(867, 84);
            label4.Name = "label4";
            label4.Size = new Size(50, 30);
            label4.TabIndex = 22;
            label4.Text = "Sáv:";
            // 
            // FormAddLesson
            // 
            AutoScaleDimensions = new SizeF(12F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1154, 712);
            Controls.Add(listBoxTime);
            Controls.Add(label4);
            Controls.Add(listBoxDay);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(listBoxRoom);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(listBoxCourse);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label5);
            Name = "FormAddLesson";
            Text = "FormAddLesson";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private Button button1;
        private Button button2;
        private Label label1;
        private ListBox listBoxCourse;
        private TextBox textBox1;
        private TextBox textBox2;
        private ListBox listBoxRoom;
        private Label label2;
        private ListBox listBoxDay;
        private Label label3;
        private ListBox listBoxTime;
        private Label label4;
    }
}