﻿using Microsoft.EntityFrameworkCore;
using SchedulePlanner.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchedulePlanner
{
    public partial class UserControlInstructors : UserControl
    {
        StudiesContext context = new StudiesContext();

        public UserControlInstructors()
        {
            InitializeComponent();
        }

        private void UserControlInstructors_Load(object sender, EventArgs e)
        {
            context.Instructors.Load();
            instructorBindingSource.DataSource = context.Instructors.Local.ToBindingList();
            statusBindingSource.DataSource = context.Statuses.ToList();
            employementBindingSource.DataSource = context.Employements.ToList();
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (instructorBindingSource.Current != null)
            {

                FormEditInstructor fei = new FormEditInstructor();

                fei.CurrentInstructor = (Instructor)instructorBindingSource.Current;

                fei.Show();
            }

        }
    }
}
