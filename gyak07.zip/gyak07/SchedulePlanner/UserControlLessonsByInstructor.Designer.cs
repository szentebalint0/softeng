﻿namespace SchedulePlanner
{
    partial class UserControlLessonsByInstructor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxInstructor = new ListBox();
            textBoxInstructorFilter = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBoxEmployment = new TextBox();
            textBoxStatus = new TextBox();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            label5 = new Label();
            buttonAddLesson = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // listBoxInstructor
            // 
            listBoxInstructor.FormattingEnabled = true;
            listBoxInstructor.ItemHeight = 30;
            listBoxInstructor.Location = new Point(22, 165);
            listBoxInstructor.Name = "listBoxInstructor";
            listBoxInstructor.Size = new Size(282, 544);
            listBoxInstructor.TabIndex = 0;
            // 
            // textBoxInstructorFilter
            // 
            textBoxInstructorFilter.Location = new Point(22, 124);
            textBoxInstructorFilter.Name = "textBoxInstructorFilter";
            textBoxInstructorFilter.PlaceholderText = "Szűrés ";
            textBoxInstructorFilter.Size = new Size(282, 35);
            textBoxInstructorFilter.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 91);
            label1.Name = "label1";
            label1.Size = new Size(91, 30);
            label1.TabIndex = 2;
            label1.Text = "Oktatók:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 724);
            label2.Name = "label2";
            label2.Size = new Size(99, 30);
            label2.TabIndex = 3;
            label2.Text = "Beosztás:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 809);
            label3.Name = "label3";
            label3.Size = new Size(84, 30);
            label3.TabIndex = 4;
            label3.Text = "Státusz:";
            // 
            // textBoxEmployment
            // 
            textBoxEmployment.Enabled = false;
            textBoxEmployment.Location = new Point(22, 757);
            textBoxEmployment.Name = "textBoxEmployment";
            textBoxEmployment.Size = new Size(282, 35);
            textBoxEmployment.TabIndex = 5;
            // 
            // textBoxStatus
            // 
            textBoxStatus.Enabled = false;
            textBoxStatus.Location = new Point(22, 842);
            textBoxStatus.Name = "textBoxStatus";
            textBoxStatus.Size = new Size(282, 35);
            textBoxStatus.TabIndex = 6;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(310, 124);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 72;
            dataGridView1.Size = new Size(1031, 585);
            dataGridView1.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(310, 91);
            label4.Name = "label4";
            label4.Size = new Size(62, 30);
            label4.TabIndex = 8;
            label4.Text = "Órák:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 18F);
            label5.Location = new Point(21, 10);
            label5.Name = "label5";
            label5.Size = new Size(351, 57);
            label5.TabIndex = 9;
            label5.Text = "Órák oktatónként";
            // 
            // buttonAddLesson
            // 
            buttonAddLesson.Location = new Point(1171, 757);
            buttonAddLesson.Name = "buttonAddLesson";
            buttonAddLesson.Size = new Size(170, 42);
            buttonAddLesson.TabIndex = 10;
            buttonAddLesson.Text = "Új óra";
            buttonAddLesson.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(995, 757);
            button1.Name = "button1";
            button1.Size = new Size(170, 42);
            button1.TabIndex = 11;
            button1.Text = "Óra törlése";
            button1.UseVisualStyleBackColor = true;
            // 
            // UserControlLessonsByInstructor
            // 
            AutoScaleDimensions = new SizeF(12F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(button1);
            Controls.Add(buttonAddLesson);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(dataGridView1);
            Controls.Add(textBoxStatus);
            Controls.Add(textBoxEmployment);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxInstructorFilter);
            Controls.Add(listBoxInstructor);
            Name = "UserControlLessonsByInstructor";
            Size = new Size(1371, 908);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBoxInstructor;
        private TextBox textBoxInstructorFilter;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBoxEmployment;
        private TextBox textBoxStatus;
        private DataGridView dataGridView1;
        private Label label4;
        private Label label5;
        private Button buttonAddLesson;
        private Button button1;
    }
}
