﻿namespace SchedulePlanner
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonInstructors = new Button();
            buttonLessonsByInsturctor = new Button();
            panel1 = new Panel();
            userControlInstructors1 = new UserControlInstructors();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // buttonInstructors
            // 
            buttonInstructors.Location = new Point(7, 6);
            buttonInstructors.Margin = new Padding(2);
            buttonInstructors.Name = "buttonInstructors";
            buttonInstructors.Size = new Size(128, 29);
            buttonInstructors.TabIndex = 0;
            buttonInstructors.Text = "Oktatók";
            buttonInstructors.UseVisualStyleBackColor = true;
            buttonInstructors.Click += buttonInstructors_Click;
            // 
            // buttonLessonsByInsturctor
            // 
            buttonLessonsByInsturctor.Location = new Point(7, 39);
            buttonLessonsByInsturctor.Margin = new Padding(2);
            buttonLessonsByInsturctor.Name = "buttonLessonsByInsturctor";
            buttonLessonsByInsturctor.Size = new Size(128, 30);
            buttonLessonsByInsturctor.TabIndex = 1;
            buttonLessonsByInsturctor.Text = "Oktatók órái";
            buttonLessonsByInsturctor.UseVisualStyleBackColor = true;
            buttonLessonsByInsturctor.Click += buttonLessonsByInsturctor_Click;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel1.Controls.Add(userControlInstructors1);
            panel1.Location = new Point(139, 6);
            panel1.Margin = new Padding(2);
            panel1.Name = "panel1";
            panel1.Size = new Size(682, 374);
            panel1.TabIndex = 2;
            // 
            // userControlInstructors1
            // 
            userControlInstructors1.Location = new Point(0, 5);
            userControlInstructors1.Margin = new Padding(2);
            userControlInstructors1.Name = "userControlInstructors1";
            userControlInstructors1.Size = new Size(678, 370);
            userControlInstructors1.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(828, 386);
            Controls.Add(panel1);
            Controls.Add(buttonLessonsByInsturctor);
            Controls.Add(buttonInstructors);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button buttonInstructors;
        private Button buttonLessonsByInsturctor;
        private Panel panel1;
        private UserControlInstructors userControlInstructors1;
    }
}
