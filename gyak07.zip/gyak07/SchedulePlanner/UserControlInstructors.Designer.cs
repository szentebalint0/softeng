﻿namespace SchedulePlanner
{
    partial class UserControlInstructors
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label5 = new Label();
            dataGridView1 = new DataGridView();
            instructorSkDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            salutationDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            nameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn1 = new DataGridViewComboBoxColumn();
            statusBindingSource = new BindingSource(components);
            employementFkDataGridViewTextBoxColumn = new DataGridViewComboBoxColumn();
            employementBindingSource = new BindingSource(components);
            lessonsDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            instructorBindingSource = new BindingSource(components);
            buttonEdit = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)statusBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)employementBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)instructorBindingSource).BeginInit();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 18F);
            label5.Location = new Point(2, 0);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(98, 32);
            label5.TabIndex = 11;
            label5.Text = "Oktatók";
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { instructorSkDataGridViewTextBoxColumn, salutationDataGridViewTextBoxColumn, nameDataGridViewTextBoxColumn, dataGridViewTextBoxColumn1, employementFkDataGridViewTextBoxColumn, lessonsDataGridViewTextBoxColumn });
            dataGridView1.DataSource = instructorBindingSource;
            dataGridView1.Location = new Point(9, 30);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 72;
            dataGridView1.Size = new Size(536, 258);
            dataGridView1.TabIndex = 12;
            // 
            // instructorSkDataGridViewTextBoxColumn
            // 
            instructorSkDataGridViewTextBoxColumn.DataPropertyName = "InstructorSk";
            instructorSkDataGridViewTextBoxColumn.HeaderText = "InstructorSk";
            instructorSkDataGridViewTextBoxColumn.Name = "instructorSkDataGridViewTextBoxColumn";
            // 
            // salutationDataGridViewTextBoxColumn
            // 
            salutationDataGridViewTextBoxColumn.DataPropertyName = "Salutation";
            salutationDataGridViewTextBoxColumn.HeaderText = "Salutation";
            salutationDataGridViewTextBoxColumn.Name = "salutationDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            nameDataGridViewTextBoxColumn.HeaderText = "Name";
            nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.DataPropertyName = "StatusFk";
            dataGridViewTextBoxColumn1.DataSource = statusBindingSource;
            dataGridViewTextBoxColumn1.DisplayMember = "Name";
            dataGridViewTextBoxColumn1.HeaderText = "StatusFk";
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.Resizable = DataGridViewTriState.True;
            dataGridViewTextBoxColumn1.SortMode = DataGridViewColumnSortMode.Automatic;
            dataGridViewTextBoxColumn1.ValueMember = "StatusId";
            // 
            // statusBindingSource
            // 
            statusBindingSource.DataSource = typeof(Models.Status);
            // 
            // employementFkDataGridViewTextBoxColumn
            // 
            employementFkDataGridViewTextBoxColumn.DataPropertyName = "EmployementFk";
            employementFkDataGridViewTextBoxColumn.DataSource = employementBindingSource;
            employementFkDataGridViewTextBoxColumn.DisplayMember = "Name";
            employementFkDataGridViewTextBoxColumn.HeaderText = "EmployementFk";
            employementFkDataGridViewTextBoxColumn.Name = "employementFkDataGridViewTextBoxColumn";
            employementFkDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            employementFkDataGridViewTextBoxColumn.SortMode = DataGridViewColumnSortMode.Automatic;
            employementFkDataGridViewTextBoxColumn.ValueMember = "EmployementId";
            // 
            // employementBindingSource
            // 
            employementBindingSource.DataSource = typeof(Models.Employement);
            // 
            // lessonsDataGridViewTextBoxColumn
            // 
            lessonsDataGridViewTextBoxColumn.DataPropertyName = "Lessons";
            lessonsDataGridViewTextBoxColumn.HeaderText = "Lessons";
            lessonsDataGridViewTextBoxColumn.Name = "lessonsDataGridViewTextBoxColumn";
            // 
            // instructorBindingSource
            // 
            instructorBindingSource.DataSource = typeof(Models.Instructor);
            // 
            // buttonEdit
            // 
            buttonEdit.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonEdit.Location = new Point(467, 292);
            buttonEdit.Margin = new Padding(2);
            buttonEdit.Name = "buttonEdit";
            buttonEdit.Size = new Size(78, 24);
            buttonEdit.TabIndex = 13;
            buttonEdit.Text = "Szerkesztés";
            buttonEdit.UseVisualStyleBackColor = true;
            buttonEdit.Click += buttonEdit_Click;
            // 
            // UserControlInstructors
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(buttonEdit);
            Controls.Add(dataGridView1);
            Controls.Add(label5);
            Margin = new Padding(2);
            Name = "UserControlInstructors";
            Size = new Size(556, 324);
            Load += UserControlInstructors_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)statusBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)employementBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)instructorBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private DataGridView dataGridView1;
        private Button buttonEdit;
        private BindingSource instructorBindingSource;
        private BindingSource statusBindingSource;
        private DataGridViewTextBoxColumn instructorSkDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn salutationDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private DataGridViewComboBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewComboBoxColumn employementFkDataGridViewTextBoxColumn;
        private BindingSource employementBindingSource;
        private DataGridViewTextBoxColumn lessonsDataGridViewTextBoxColumn;
    }
}
