using gyak_06.Models;

namespace gyak_06
{
    public partial class Form1 : Form
    {

        TextbookSupportContext context;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            context = new TextbookSupportContext();
            GetStudent();
            GetTextBook();
        }


        private void GetStudent()
        {

            var studentQuery = from x in context.Students
                               where x.Name!.Contains(txtStudent.Text)
                               select x;

            studentBindingSource.DataSource = studentQuery.ToList();
        }

        private void GetTextBook()
        {

            var textBookQuery = from x in context.Textbooks
                                where x.Title!.Contains(txtTextBook.Text)
                                select x;

            textbookBindingSource.DataSource = textBookQuery.ToList();

        }

        private void txtStudent_TextChanged(object sender, EventArgs e)
        {
            GetStudent();
        }

        private void txtTextBook_TextChanged(object sender, EventArgs e)
        {
            GetTextBook();
        }

        private void studentBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            GetOrders();

        }

        private void GetOrders()
        {
            Student currentStudent = (Student)studentBindingSource.Current;


            if (currentStudent != null)
            {
                var orderQuery = from x in context.Orders
                                 where x.StudentFk == currentStudent.StudentId
                                 select new
                                 {

                                     x.OrderSk,
                                     x.TextbookFkNavigation!.Title

                                 };


                orderWithTitleBindingSource.DataSource = orderQuery.ToList();
            }

            double aidSum = double.Parse(textBox1.Text);

            double? orderSum = (from x in context.Orders
                                select x.TextbookFkNavigation!.Price).Sum();

            double? studentOrderSum = (from x in context.Orders
                                       where x.StudentFk == currentStudent!.StudentId
                                       select x.TextbookFkNavigation!.Price).Sum();
            textBox4.Text = orderSum.ToString();

            textBox2.Text = studentOrderSum.ToString();

            textBox3.Text =  (studentOrderSum * aidSum / orderSum).ToString();

            textBox5.Text = (aidSum / orderSum).ToString();


        }

        private void rightButton_Click(object sender, EventArgs e)
        {

            OrderWithTitle order = (OrderWithTitle)orderWithTitleBindingSource.Current;

            var orderToRemove = from x in context.Orders
                                where x.OrderSk == order.OrderSk
                                select x;

            try
            {
                context.Orders.Remove(orderToRemove.FirstOrDefault()!);
                context.SaveChanges();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.InnerException!.Message);
            }

            GetOrders();

        }

        private void leftButton_Click(object sender, EventArgs e)
        {
            Student student = (Student)studentBindingSource.Current;
            Textbook textbook = (Textbook)textbookBindingSource.Current;

            Order order = new Order();
            order.StudentFk = student.StudentId;
            order.TextbookFk = textbook.TextbookId;

            context.Orders.Add(order);

            try
            {
                context.SaveChanges();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.InnerException.Message);
            }

            GetOrders();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            GetOrders();
        }
    }
}
