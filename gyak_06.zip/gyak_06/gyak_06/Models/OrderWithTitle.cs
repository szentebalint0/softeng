﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gyak_06.Models
{
    public class OrderWithTitle
    {
        public string Title { get; set; }
        public int OrderSk { get; set; }

    }
}
