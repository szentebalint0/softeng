﻿namespace gyak_06
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtStudent = new TextBox();
            txtTextBook = new TextBox();
            listStudent = new ListBox();
            studentBindingSource = new BindingSource(components);
            listTextBook = new ListBox();
            textbookBindingSource = new BindingSource(components);
            listOrder = new ListBox();
            orderWithTitleBindingSource = new BindingSource(components);
            orderBindingSource = new BindingSource(components);
            leftButton = new Button();
            rightButton = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)studentBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)textbookBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)orderWithTitleBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)orderBindingSource).BeginInit();
            SuspendLayout();
            // 
            // txtStudent
            // 
            txtStudent.Location = new Point(24, 21);
            txtStudent.Name = "txtStudent";
            txtStudent.Size = new Size(176, 23);
            txtStudent.TabIndex = 0;
            txtStudent.TextChanged += txtStudent_TextChanged;
            // 
            // txtTextBook
            // 
            txtTextBook.Location = new Point(581, 21);
            txtTextBook.Name = "txtTextBook";
            txtTextBook.Size = new Size(176, 23);
            txtTextBook.TabIndex = 1;
            txtTextBook.TextChanged += txtTextBook_TextChanged;
            // 
            // listStudent
            // 
            listStudent.DataSource = studentBindingSource;
            listStudent.DisplayMember = "Name";
            listStudent.FormattingEnabled = true;
            listStudent.ItemHeight = 15;
            listStudent.Location = new Point(24, 67);
            listStudent.Name = "listStudent";
            listStudent.Size = new Size(176, 379);
            listStudent.TabIndex = 2;
            // 
            // studentBindingSource
            // 
            studentBindingSource.DataSource = typeof(Models.Student);
            studentBindingSource.CurrentChanged += studentBindingSource_CurrentChanged;
            // 
            // listTextBook
            // 
            listTextBook.DataSource = textbookBindingSource;
            listTextBook.DisplayMember = "Title";
            listTextBook.FormattingEnabled = true;
            listTextBook.ItemHeight = 15;
            listTextBook.Location = new Point(581, 67);
            listTextBook.Name = "listTextBook";
            listTextBook.Size = new Size(176, 379);
            listTextBook.TabIndex = 3;
            // 
            // textbookBindingSource
            // 
            textbookBindingSource.DataSource = typeof(Models.Textbook);
            // 
            // listOrder
            // 
            listOrder.DataSource = orderWithTitleBindingSource;
            listOrder.DisplayMember = "Title";
            listOrder.FormattingEnabled = true;
            listOrder.ItemHeight = 15;
            listOrder.Location = new Point(244, 67);
            listOrder.Name = "listOrder";
            listOrder.Size = new Size(220, 379);
            listOrder.TabIndex = 4;
            // 
            // orderWithTitleBindingSource
            // 
            orderWithTitleBindingSource.DataSource = typeof(Models.OrderWithTitle);
            // 
            // orderBindingSource
            // 
            orderBindingSource.DataSource = typeof(Models.Order);
            // 
            // leftButton
            // 
            leftButton.Location = new Point(490, 255);
            leftButton.Name = "leftButton";
            leftButton.Size = new Size(63, 58);
            leftButton.TabIndex = 5;
            leftButton.Text = "<";
            leftButton.UseVisualStyleBackColor = true;
            leftButton.Click += leftButton_Click;
            // 
            // rightButton
            // 
            rightButton.Location = new Point(490, 178);
            rightButton.Name = "rightButton";
            rightButton.Size = new Size(63, 58);
            rightButton.TabIndex = 6;
            rightButton.Text = ">";
            rightButton.UseVisualStyleBackColor = true;
            rightButton.Click += rightButton_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(24, 469);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(176, 23);
            textBox1.TabIndex = 7;
            textBox1.Text = "100000";
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(244, 469);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(176, 23);
            textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(490, 469);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(176, 23);
            textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(24, 525);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(176, 23);
            textBox4.TabIndex = 10;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(244, 525);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(176, 23);
            textBox5.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 451);
            label1.Name = "label1";
            label1.Size = new Size(119, 15);
            label1.TabIndex = 12;
            label1.Text = "Támogatás összérték:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(244, 449);
            label2.Name = "label2";
            label2.Size = new Size(162, 15);
            label2.TabIndex = 13;
            label2.Text = "Hallgató rendelésének értéke:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(490, 449);
            label3.Name = "label3";
            label3.Size = new Size(145, 15);
            label3.TabIndex = 14;
            label3.Text = "Hallgatóra jutó támogatás";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 507);
            label4.Name = "label4";
            label4.Size = new Size(123, 15);
            label4.TabIndex = 15;
            label4.Text = "Rendelések összértéke";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(244, 507);
            label5.Name = "label5";
            label5.Size = new Size(134, 15);
            label5.TabIndex = 16;
            label5.Text = "Támogatás forintonként";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 560);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(rightButton);
            Controls.Add(leftButton);
            Controls.Add(listOrder);
            Controls.Add(listTextBook);
            Controls.Add(listStudent);
            Controls.Add(txtTextBook);
            Controls.Add(txtStudent);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)studentBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)textbookBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)orderWithTitleBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)orderBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtStudent;
        private TextBox txtTextBook;
        private ListBox listStudent;
        private ListBox listTextBook;
        private ListBox listOrder;
        private BindingSource studentBindingSource;
        private BindingSource textbookBindingSource;
        private BindingSource orderBindingSource;
        private BindingSource orderWithTitleBindingSource;
        private Button leftButton;
        private Button rightButton;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}
