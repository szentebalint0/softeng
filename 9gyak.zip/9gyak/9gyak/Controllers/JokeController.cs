﻿using _9gyak.JokeModels;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace _9gyak.Controllers
{
    [Route("api/joke")]
    [ApiController]
    public class JokeController : ControllerBase
    {

        FunnyDatabaseContext context = new();

        // GET: api/<JokeController>
        [HttpGet]
        public IActionResult Get()
        {
            var x = context.Jokes.ToList();
            return Ok(x);
        }

        // GET api/<JokeController>/5
        [HttpGet("{xxx}")]
        public IActionResult Get(int xxx)
        {
            var query = from x in context.Jokes
                    where x.JokeSk == xxx
                    select x;

            return Ok(query.FirstOrDefault());
        }

        // POST api/<JokeController>
        [HttpPost]
        public void Post([FromBody] Joke ujvicc)
        {

            context.Jokes.Add(ujvicc);
            context.SaveChanges();
        }

        // PUT api/<JokeController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<JokeController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {

            var query = (from x in context.Jokes
                         where x.JokeSk == id
                         select x).FirstOrDefault();

            context.Jokes.Remove(query);
            context.SaveChanges();
        }
    }
}
