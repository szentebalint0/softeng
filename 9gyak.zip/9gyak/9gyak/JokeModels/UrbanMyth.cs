﻿using System;
using System.Collections.Generic;

namespace _9gyak.JokeModels;

public partial class UrbanMyth
{
    public int MythId { get; set; }

    public string MythTitle { get; set; } = null!;

    public string? MythDescription { get; set; }

    public bool IsTrue { get; set; }

    public string? Source { get; set; }
}
